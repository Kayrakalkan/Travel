//
//  Course.swift
//  Travel
//
//  Created by Kayra Kalkan on 29.12.2020.
//

//import Foundation
//import SwiftUI
//import CoreLocation
//
//struct Course : Hashable, Codable, Identifiable{
//    
//    var id = UUID().uuidString
//    var name : String
//    var numCourse : Int
//    
//    public var asset: String
//    var image: Image {
//        Image(asset)
//    }
//}
