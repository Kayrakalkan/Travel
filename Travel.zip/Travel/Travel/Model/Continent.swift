//
//  Continent.swift
//  Travel
//
//  Created by Kayra Kalkan on 18.12.2020.
//

import Foundation
import SwiftUI

struct Continent: Hashable, Codable, Identifiable {
    
    var id: Int
    var name: String
    
    private var imageName: String
    var image: Image {
        Image(imageName)
    }
    
}


