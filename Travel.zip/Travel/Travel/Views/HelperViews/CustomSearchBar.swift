//
//  CustomSearchBar.swift
//  Travel
//
//  Created by Kayra Kalkan on 23.12.2020.
//

import Foundation
import SwiftUI


struct CustomSearchBar: UIViewRepresentable {
    @Binding var text: String
    func makeUIView(context: UIViewRepresentableContext<CustomSearchBar>) -> UISearchBar {
        
        let searchbar = UISearchBar(frame: .zero)
        searchbar.delegate = context.coordinator
        return searchbar

    }
    func updateUIView(_ uiView: UISearchBar, context: UIViewRepresentableContext<CustomSearchBar>) {

        uiView.text = text

    }
    func makeCoordinator() -> CustomSearchBar.Coordinator {
        return Coordinator(text: $text)
    }
    
    class Coordinator: NSObject, UISearchBarDelegate{
        @Binding var text: String
        
        init(text: Binding<String>){
            _text = text
        }
        func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String){
            text = searchText
        }
    }
}
