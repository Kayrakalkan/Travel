//
//  ImageView.swift
//  Travel
//
//  Created by Kayra Kalkan on 2.01.2021.
//

import SwiftUI

struct ImageView: View {
    var image: Image
    
    var body: some View {
        image
        .resizable()
        .aspectRatio(3 / 2, contentMode: .fit)
        .cornerRadius(23)
        
    }
}

struct ImageView_Previews: PreviewProvider {
    static var previews: some View {
        ImageView(image: Image("hotel"))
    }
}
