import SwiftUI
 
struct SearchBar: View {
    
    @State var searchedText = ""
    
    var body: some View {
            VStack {
                HStack {
                    TextField("Search...", text: $searchedText)
                        .padding(.leading, 24)
                }
                .padding()
                .background(Color(.systemGray5))
                .cornerRadius(100)
                .padding(.horizontal)
                .overlay(
                    HStack {
                        Image(systemName: "magnifyingglass")
                        Spacer()
                        Button(action: { }, label: {
                            Image(systemName: "xmark.circle.fill")
                                .padding(.vertical)
                        })
                    }
                    .padding(.horizontal, 28)
                    .foregroundColor(.gray)
                )
                Spacer()
            }
    }
}
 
struct SearchBar_Previews: PreviewProvider {
    static var previews: some View {
        SearchBar()
    }
}
