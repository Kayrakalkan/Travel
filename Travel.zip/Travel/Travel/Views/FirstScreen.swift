//
//  FirstScreen.swift
//  Travel
//
//  Created by Kayra Kalkan on 18.12.2020.
//

import SwiftUI

struct FirstScreen: View {
    var body: some View {
        Text("hello world")
        
    }
}

struct FirstScreen_Previews: PreviewProvider {
    static var previews: some View {
        FirstScreen()
    }
}
