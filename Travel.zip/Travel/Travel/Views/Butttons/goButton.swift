//
//  goButton.swift
//  Travel
//
//  Created by Kayra Kalkan on 18.12.2020.
//

import SwiftUI

struct goButton: View {
    @EnvironmentObject var modelData: ModelData
    var landmark: Landmark
    
    var body: some View {
        
        Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
             
            Link("Visit",
                 destination: URL(string: "\(landmark.visit)")!)
                .font(.title)
                .foregroundColor(.blue)
            Image(systemName: "location.fill")
            
                
        })
    }
}

struct goButton_Previews: PreviewProvider {
    static let modelData = ModelData()

      static var previews: some View {
        goButton(landmark: modelData.landmarks[0])
        .environmentObject(modelData)
    }
}
