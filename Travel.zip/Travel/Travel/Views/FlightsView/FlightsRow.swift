//
//  FlightRow.swift
//  Travel
//
//  Created by Kayra Kalkan on 1.01.2021.
//

import SwiftUI

struct FlightsRow: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct FlightsRow_Previews: PreviewProvider {
    static var previews: some View {
        FlightRow()
    }
}
