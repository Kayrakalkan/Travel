//
//  CatagoryHome.swift
//  Travel
//
//  Created by Kayra Kalkan on 18.12.2020.
//

import SwiftUI

struct CatagoryHome: View {
    @EnvironmentObject var modelData: ModelData

    var body: some View {
        NavigationView {
            List {
                ForEach(modelData.categories.keys.sorted(), id: \.self) { key in
                Text(key)
                    }
            }
            .navigationTitle("Featured")
        }
    }
}

struct CatagoryHome_Previews: PreviewProvider {
    static var previews: some View {
        CatagoryHome()
        .environmentObject(ModelData())

    }
}
