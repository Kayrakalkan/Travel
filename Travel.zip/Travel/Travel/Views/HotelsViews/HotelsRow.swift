import SwiftUI

struct HotelsRow: View {
    
    var landmark: Landmark

    var body: some View {
        HStack {
            landmark.image
            .resizable()
            .frame(width: 50, height: 50)
            
            
            Text((landmark.hotelName))
            Spacer()
        }
    }
}

struct HotelsRow_Previews: PreviewProvider {
    static var landmarks = ModelData().landmarks
    
    static var previews: some View {
        Group{
            HotelsRow(landmark: landmarks[0])
            
            HotelsRow(landmark: landmarks[1])
        }
        .previewLayout(.fixed(width: 300, height: 70))

    }
}

