
import SwiftUI

struct HotelsList: View {
    @EnvironmentObject var modelData: ModelData
    @State private var showFavoritesOnly = false

    var filteredLandmarks: [Landmark] {
        modelData.landmarks.filter { landmark in
            (!showFavoritesOnly || landmark.isFavorite)
        }
    }
    var body: some View {
        NavigationView {
            List {
                ForEach(filteredLandmarks) { landmark in
                    NavigationLink(destination: HotelsDetail(landmark: landmark)) {
                        HotelsRow(landmark: landmark)
                    }
                }
            }
            .navigationTitle("Hotels")
        }
    }
}


struct HotelsList_Previews: PreviewProvider {
    static var previews: some View {
        HotelsList()
        .environmentObject(ModelData())
    }
}
