import SwiftUI

struct ContinentList: View {
    @EnvironmentObject var modelData: ModelData
    @State private var showFavoritesOnly = false

    var filteredContinents: [Continent] {
        modelData.continents.filter { continent in
            (!showFavoritesOnly || continent.isFavorite)
        }
    }

    var body: some View {
        NavigationView {
            List {
                ForEach(filteredContinents) { continent in
                    NavigationLink(destination: ContinentDetail(continent: continent)) {
                        ContinentRow(continent: continent)
                    }
                }
            }
            .navigationTitle("Continents")
        }
    }


struct ContinentList_Previews: PreviewProvider {
    static var previews: some View {
            ContinentList()
            .environmentObject(ModelData())
    }
}



}
