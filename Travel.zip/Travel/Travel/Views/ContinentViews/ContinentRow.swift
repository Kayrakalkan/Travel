import SwiftUI

struct ContinentRow: View {
    
    var continent: Continent

    var body: some View {
        HStack {
            continent.image
            .resizable()
            .frame(width: 50, height: 50)
       
            Text(continent.name)
            
            Spacer()
            if continent.isFavorite {
                Image(systemName: "star.circle")
                .foregroundColor(.blue)
            }
        }
    }
}

struct ContinentRow_Previews: PreviewProvider {
    static var continents = ModelData().continents
    
    static var previews: some View {
        Group{
            ContinentRow(continent: continents[0])
            
            ContinentRow(continent: continents[1])
        }
        .previewLayout(.fixed(width: 300, height: 70))

    }
}

