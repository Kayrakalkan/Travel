//
//  ContinentDetail.swift
//  Travel
//
//  Created by Kayra Kalkan on 19.12.2020.
//

import SwiftUI

struct ContinentDetail: View {
    var continent: Continent

    var body: some View {
        LandmarkList()
    }
}

struct ContinentDetail_Previews: PreviewProvider {
static var continents = ModelData().continents

    static var previews: some View {
        ContinentDetail(continent: continents[0] )
        .environmentObject(ModelData())

    }
}
