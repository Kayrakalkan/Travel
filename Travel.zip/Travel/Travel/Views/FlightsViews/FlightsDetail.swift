//Created by Kayra Kalkan
//12/2020 by Keyra

import SwiftUI

struct FlightsDetail: View {
    @EnvironmentObject var modelData: ModelData
    var body: some View {
        
        Webview(url: "https://www.wingie.co.uk/set-currency/GBP")
    }
}
struct FlightsDetail_Previews: PreviewProvider {
    static let modelData = ModelData()
    
    static var previews: some View {
        FlightsDetail()
        .environmentObject(modelData)
    }
}
